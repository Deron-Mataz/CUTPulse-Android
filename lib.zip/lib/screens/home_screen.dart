import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cutpulse/screens/search_screen.dart';
import 'package:cutpulse/screens/upload_screen.dart';
import 'package:cutpulse/screens/profile_screen.dart';
import 'package:cutpulse/widgets/post_widget.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _selectedIndex = 0;

  // Mock posts feed
  final List<Map<String, String?>> posts = [
    {
      "username": "Alice",
      "profileImage": null,
      "textContent":
          "I can hardly believe this day has finally come! Four years of late nights, countless assignments, and unforgettable memories have led to this moment. Graduating feels surreal — I’m so proud of everything we’ve accomplished and so grateful to everyone who supported me along the way. Here’s to new beginnings, chasing dreams, and making the most of every opportunity life throws at us. #GraduationDay #ClassOf2025 #FeelingAccomplished",
      "imageUrl": "assets/images/post_image.jpg",
    },
    {
      "username": "Bob",
      "profileImage": null,
      "textContent": "Viva SASCO Viva!!✊✊✊✊",
      "imageUrl": null,
    },
    {
      "username": "Charlie",
      "profileImage": null,
      "textContent": "Check out this view!",
      "imageUrl": "assets/images/post_image2.jpg",
    },
  ];

  // Screens linked to bottom navigation
  late final List<Widget> _pages;

  @override
  void initState() {
    super.initState();
    _pages = [
      // Feed / Home Screen
      ListView.builder(
        itemCount: posts.length,
        itemBuilder: (context, index) {
          final post = posts[index];
          return PostWidget(
            username: post['username']!,
            profileImage: post['profileImage'] ?? "",
            textContent: post['textContent'],
            imageUrl: post['imageUrl'],
          );
        },
      ),

      // Search Screen
      const SearchScreen(),

      // Upload Screen
      const UploadScreen(),

      // Profile Screen
      const ProfileScreen(),
    ];
  }

  // Called when an icon is tapped
  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  // Build each icon in bottom navigation
  Widget _buildNavItem(IconData icon, int index) {
    final isSelected = _selectedIndex == index;

    return Expanded(
      child: InkWell(
        onTap: () => _onItemTapped(index),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isSelected ? Colors.blue : Colors.grey[600],
              size: 28,
            ),
            if (isSelected)
              Container(
                margin: const EdgeInsets.only(top: 4),
                height: 3,
                width: 24,
                decoration: BoxDecoration(
                  color: Colors.blue,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            if (!isSelected) const SizedBox(height: 7),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 1,
        toolbarHeight: 60,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            CustomPaint(size: const Size(32, 32), painter: LogoPainter()),
            const SizedBox(width: 8),
            Text(
              "CUTPulse",
              style: GoogleFonts.poppins(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.blueAccent,
              ),
            ),
          ],
        ),
      ),
      body: _pages[_selectedIndex],
      bottomNavigationBar: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: const BoxDecoration(
          color: Colors.white,
          border: Border(top: BorderSide(color: Colors.black12, width: 1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _buildNavItem(Icons.home, 0),
            _buildNavItem(Icons.search, 1),
            _buildNavItem(Icons.add_box_outlined, 2),
            _buildNavItem(Icons.person, 3),
          ],
        ),
      ),
    );
  }
}

// Simple CUTPulse Logo
class LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    // Draw gradient circle
    final paint = Paint()
      ..shader = LinearGradient(
        colors: [Colors.white, Colors.lightBlueAccent],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final circle = Path()
      ..addOval(
        Rect.fromCircle(
          center: Offset(size.width / 2, size.height / 2),
          radius: size.width / 2,
        ),
      );
    canvas.drawPath(circle, paint);

    // Pulse wave inside (scaled)
    final pulsePaint = Paint()
      ..color = Colors.blueAccent
      ..strokeWidth = 2.5
      ..style = PaintingStyle.stroke;

    final centerY = size.height / 2;
    final padding = size.width * 0.15; // 15% inside the circle
    final leftX = padding;
    final rightX = size.width - padding;
    final segmentWidth = (rightX - leftX) / 4;
    final pulseHeight = size.height * 0.15; // 15% of height for peaks

    final pulsePath = Path();
    pulsePath.moveTo(leftX, centerY);
    pulsePath.lineTo(leftX + segmentWidth, centerY - pulseHeight);
    pulsePath.lineTo(leftX + segmentWidth * 2, centerY + pulseHeight);
    pulsePath.lineTo(leftX + segmentWidth * 3, centerY - pulseHeight);
    pulsePath.lineTo(rightX, centerY);

    canvas.drawPath(pulsePath, pulsePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
