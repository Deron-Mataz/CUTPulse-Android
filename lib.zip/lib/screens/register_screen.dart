import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'home_screen.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();

  bool isValidCUTEmail(String email) {
    return email.endsWith('@cut.ac.za') || email.endsWith('@stud.cut.ac.za');
  }

  bool isStrongPassword(String password) {
    final regex = RegExp(
      r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#\$%^&*]).{8,}$',
    );
    return regex.hasMatch(password);
  }

  bool isLoading = false;
  bool passwordVisible = false;
  bool confirmPasswordVisible = false;
  String usernameMessage = '';
  Color usernameMessageColor = Colors.green;

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // Username validation regex: one word, letters/numbers/underscore/dot, starts with letter
  bool isValidUsername(String username) {
    final regex = RegExp(r'^[A-Za-z][A-Za-z0-9_.]*$');
    return regex.hasMatch(username);
  }

  Future<void> checkUsernameAvailability(String username) async {
    if (!isValidUsername(username)) {
      setState(() {
        usernameMessage = 'Invalid username';
        usernameMessageColor = Colors.red;
      });
      return;
    }

    final query = await _firestore
        .collection('users')
        .where('username', isEqualTo: username)
        .get();
    if (query.docs.isEmpty) {
      setState(() {
        usernameMessage = 'Username is available';
        usernameMessageColor = const Color.fromARGB(255, 34, 100, 36);
      });
    } else {
      setState(() {
        usernameMessage = 'Username already taken';
        usernameMessageColor = Colors.red;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFF2196F3), Color(0xFF00BCD4)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24.0),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo
                    CustomPaint(
                      size: const Size(100, 100),
                      painter: LogoPainter(),
                    ),
                    const SizedBox(height: 20),
                    Text(
                      "Create Account",
                      style: GoogleFonts.poppins(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      "Join the CUT Community",
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        color: Colors.white70,
                      ),
                    ),
                    const SizedBox(height: 40),

                    _buildTextFormField(
                      controller: nameController,
                      label: "Full Name",
                      icon: Icons.person,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter your full name';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildTextFormField(
                      controller: usernameController,
                      label: "Username",
                      icon: Icons.person_outline,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter a username';
                        }
                        if (!isValidUsername(value.trim())) {
                          return 'Invalid username';
                        }
                        return null;
                      },
                      onChanged: (value) =>
                          checkUsernameAvailability(value.trim()),
                    ),
                    const SizedBox(height: 4),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        usernameMessage,
                        style: GoogleFonts.poppins(
                          color: usernameMessageColor,
                          fontSize: 12,
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),

                    _buildTextFormField(
                      controller: emailController,
                      label: "Email",
                      icon: Icons.email,
                      validator: (value) {
                        if (value == null || value.trim().isEmpty) {
                          return 'Please enter your email';
                        }
                        if (!isValidCUTEmail(value.trim())) {
                          return 'Please enter a valid CUT email';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildTextFormField(
                      controller: passwordController,
                      label: "Password",
                      icon: Icons.lock,
                      obscure: !passwordVisible,
                      suffixIcon: IconButton(
                        icon: Icon(
                          passwordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.white70,
                        ),
                        onPressed: () {
                          setState(() {
                            passwordVisible = !passwordVisible;
                          });
                        },
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter your password';
                        }
                        if (!isStrongPassword(value)) {
                          return 'Password must be 8+ characters, include upper & lower case letters,\na number, and a special character';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 16),

                    _buildTextFormField(
                      controller: confirmPasswordController,
                      label: "Confirm Password",
                      icon: Icons.lock_outline,
                      obscure: !confirmPasswordVisible,
                      suffixIcon: IconButton(
                        icon: Icon(
                          confirmPasswordVisible
                              ? Icons.visibility
                              : Icons.visibility_off,
                          color: Colors.white70,
                        ),
                        onPressed: () {
                          setState(() {
                            confirmPasswordVisible = !confirmPasswordVisible;
                          });
                        },
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please confirm your password';
                        }
                        if (value != passwordController.text) {
                          return 'Passwords do not match';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 24),

                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 80,
                          vertical: 16,
                        ),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30),
                        ),
                        backgroundColor: Colors.white,
                      ),
                      onPressed: isLoading ? null : _registerUser,
                      child: isLoading
                          ? const SizedBox(
                              height: 20,
                              width: 20,
                              child: CircularProgressIndicator(
                                color: Color(0xFF2196F3),
                                strokeWidth: 2,
                              ),
                            )
                          : Text(
                              "Register",
                              style: GoogleFonts.poppins(
                                color: Color(0xFF2196F3),
                                fontWeight: FontWeight.bold,
                                fontSize: 18,
                              ),
                            ),
                    ),
                    const SizedBox(height: 20),
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Text(
                        "Already have an account? Login",
                        style: GoogleFonts.poppins(
                          color: Colors.white,
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextFormField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    bool obscure = false,
    Widget? suffixIcon,
    required String? Function(String?) validator,
    Function(String)? onChanged,
  }) {
    return TextFormField(
      controller: controller,
      obscureText: obscure,
      validator: validator,
      onChanged: onChanged,
      style: const TextStyle(color: Colors.white),
      decoration: InputDecoration(
        prefixIcon: Icon(icon, color: Colors.white70),
        suffixIcon: suffixIcon,
        labelText: label,
        labelStyle: GoogleFonts.poppins(color: Colors.white70),
        filled: true,
        fillColor: Colors.white.withOpacity(0.2),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none,
        ),
      ),
    );
  }

  Future<void> _registerUser() async {
    if (_formKey.currentState!.validate()) {
      setState(() {
        isLoading = true;
      });
      try {
        final usernameTrimmed = usernameController.text.trim();
        final checkQuery = await _firestore
            .collection('users')
            .where('username', isEqualTo: usernameTrimmed)
            .get();
        if (checkQuery.docs.isNotEmpty) {
          setState(() {
            usernameMessage = 'Username already taken';
            usernameMessageColor = Colors.red;
            isLoading = false;
          });
          return;
        }

        UserCredential userCredential = await _auth
            .createUserWithEmailAndPassword(
              email: emailController.text.trim(),
              password: passwordController.text.trim(),
            );

        // Save additional info to Firestore
        await _firestore.collection('users').doc(userCredential.user!.uid).set({
          'fullName': nameController.text.trim(),
          'username': usernameTrimmed,
          'email': emailController.text.trim(),
          'createdAt': Timestamp.now(),
        });

        // Navigate to home screen
        if (!mounted) return;
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => const HomeScreen()),
        );
      } on FirebaseAuthException catch (e) {
        String message = e.message ?? 'Registration failed';
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(message), backgroundColor: Colors.red),
        );
      } finally {
        if (mounted) setState(() => isLoading = false);
      }
    }
  }
}

class LogoPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..shader = LinearGradient(
        colors: [Colors.white, Colors.lightBlueAccent],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));

    final path = Path();
    path.addOval(
      Rect.fromCircle(
        center: Offset(size.width / 2, size.height / 2),
        radius: size.width / 2,
      ),
    );
    canvas.drawPath(path, paint);

    // Pulse wave inside
    final pulsePaint = Paint()
      ..color = Colors.blueAccent
      ..strokeWidth = 4
      ..style = PaintingStyle.stroke;

    final pulsePath = Path();

    // Original pulse points
    final originalPoints = [
      Offset(20, size.height / 2),
      Offset(40, size.height / 2),
      Offset(50, size.height / 3),
      Offset(70, size.height * 2 / 3),
      Offset(100, size.height / 2),
    ];

    // Compute horizontal offset to center pulse
    final pulseWidth = originalPoints.last.dx - originalPoints.first.dx;
    final offsetX = (size.width - pulseWidth) / 2 - originalPoints.first.dx;

    // Apply horizontal shift
    for (int i = 0; i < originalPoints.length; i++) {
      originalPoints[i] = originalPoints[i].translate(offsetX, 0);
    }

    // Draw the pulse
    pulsePath.moveTo(originalPoints[0].dx, originalPoints[0].dy);
    for (int i = 1; i < originalPoints.length; i++) {
      pulsePath.lineTo(originalPoints[i].dx, originalPoints[i].dy);
    }

    canvas.drawPath(pulsePath, pulsePaint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
