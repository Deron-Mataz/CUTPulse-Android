import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import '../widgets/post_widget.dart'; // Make sure this path is correct

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  // Dummy posts for profile
  final List<Map<String, dynamic>> dummyPosts = const [
    {
      "username": "Deron",
      "profileImage": "",
      "textContent":
          "Just finished my final project for the semester! Feeling accomplished and exhausted at the same time.",
      "imageUrl": "assets/images/post_image5.jpg",
    },
    {
      "username": "Deron",
      "profileImage": "",
      "textContent": "Graduation day memories!",
      "imageUrl": "assets/images/post_image3.jpg",
    },
    {
      "username": "Deron",
      "profileImage": "",
      "textContent":
          "Had the most amazing photoshoot today! 🌟 Spent hours experimenting with different outfits, lighting, and poses, and I’m so excited about how the shots turned out. It was a bit tiring, but totally worth it seeing the creativity and effort come together. Big thanks to the amazing photographer and the team who helped make everything perfect. Can’t wait to share the final pictures soon! Feeling inspired and motivated for more shoots in the future!",
      "imageUrl": "assets/images/post_image4.jpg",
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: ListView(
        children: [
          // Cover image + profile picture + stats
          Stack(
            clipBehavior: Clip.none,
            children: [
              // Cover image
              Container(
                height: 90,
                width: double.infinity,
                decoration: BoxDecoration(
                  image: const DecorationImage(
                    image: AssetImage('assets/images/cover_placeholder.jpg'),
                    fit: BoxFit.cover,
                  ),
                  color: Colors.blueGrey[200],
                ),
              ),
              // Profile picture + stats
              Positioned(
                bottom: -50,
                left: 16,
                right: 16,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    CircleAvatar(
                      radius: 50,
                      backgroundColor: Colors.grey[300],
                      backgroundImage: const AssetImage(
                        'assets/images/profile_placeholder.jpg',
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          _buildStatItem("Posts", "12"),
                          _buildStatItem("Followers", "1.2K"),
                          _buildStatItem("Following", "345"),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 60), // space for profile pic overlay
          // Name, username, bio, buttons
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Deron Mataz",
                  style: GoogleFonts.poppins(
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  "@deron_mataz",
                  style: GoogleFonts.poppins(color: Colors.grey[600]),
                ),
                const SizedBox(height: 8),
                Text(
                  "4th Year IT Student • Student Activist",
                  style: GoogleFonts.poppins(fontSize: 14, color: Colors.black),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () {},
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(8),
                          ),
                        ),
                        child: Text(
                          "Edit Profile",
                          style: GoogleFonts.poppins(
                            color: Colors.white,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      height: 40,
                      width: 40,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: Colors.grey),
                      ),
                      child: IconButton(
                        padding: EdgeInsets.zero,
                        icon: const Icon(Icons.more_horiz),
                        onPressed: () {},
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
              ],
            ),
          ),

          // Posts
          ...dummyPosts.map(
            (post) => PostWidget(
              username: post["username"],
              profileImage: post["profileImage"],
              textContent: post["textContent"],
              imageUrl: post["imageUrl"],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String number) {
    return Column(
      children: [
        Text(
          number,
          style: GoogleFonts.poppins(fontSize: 16, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 4),
        Text(label, style: GoogleFonts.poppins(color: Colors.grey[600])),
      ],
    );
  }
}
