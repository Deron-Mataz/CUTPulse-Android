import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({super.key});

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _focusNode = FocusNode();

  // Example recent searches
  final List<Map<String, String>> recentAccounts = [
    {"username": "Alice", "name": "Alice Johnson"},
    {"username": "Bob", "name": "Bob Smith"},
    {"username": "Charlie", "name": "Charlie Brown"},
    {"username": "Diana", "name": "Diana Prince"},
    {"username": "Eve", "name": "Eve Adams"},
    {"username": "Frank", "name": "Frank Wright"},
    {"username": "Grace", "name": "Grace Lee"},
    {"username": "Hannah", "name": "Hannah Scott"},
    {"username": "Ian", "name": "Ian Carter"},
    {"username": "Jack", "name": "Jack Wilson"},
    {"username": "Kara", "name": "Kara Thomas"},
  ];

  // Example suggestions
  final List<Map<String, String>> allAccounts = [
    {"username": "Alice", "name": "Alice Johnson"},
    {"username": "Bob", "name": "Bob Smith"},
    {"username": "Charlie", "name": "Charlie Brown"},
    {"username": "Diana", "name": "Diana Prince"},
    {"username": "Eve", "name": "Eve Adams"},
    {"username": "Frank", "name": "Frank Wright"},
    {"username": "Grace", "name": "Grace Lee"},
    {"username": "Hannah", "name": "Hannah Scott"},
    {"username": "Ian", "name": "Ian Carter"},
    {"username": "Jack", "name": "Jack Wilson"},
    {"username": "Kara", "name": "Kara Thomas"},
    {"username": "Liam", "name": "Liam Walker"},
    {"username": "Mia", "name": "Mia Lewis"},
    {"username": "Noah", "name": "Noah Young"},
    {"username": "Olivia", "name": "Olivia Hall"},
    {"username": "Paul", "name": "Paul Allen"},
    {"username": "Quinn", "name": "Quinn Martin"},
    {"username": "Ruby", "name": "Ruby Clark"},
    {"username": "Sophia", "name": "Sophia Rodriguez"},
    {"username": "Tom", "name": "Tom Bennett"},
  ];

  List<Map<String, String>> filteredAccounts = [];

  @override
  void initState() {
    super.initState();
    _focusNode.requestFocus(); // keyboard pops up
    filteredAccounts = allAccounts;
    _searchController.addListener(_onSearchChanged);
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      filteredAccounts = allAccounts
          .where(
            (acc) =>
                acc['username']!.toLowerCase().contains(query) ||
                acc['name']!.toLowerCase().contains(query),
          )
          .toList();
    });
  }

  void _clearSearch() {
    _searchController.clear();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _focusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      body: SafeArea(
        child: Column(
          children: [
            // Sticky Search Bar
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 8.0,
                vertical: 16,
              ),
              child: Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.arrow_back),
                    onPressed: () => Navigator.pop(context),
                  ),
                  const SizedBox(width: 4),
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      focusNode: _focusNode,
                      decoration: InputDecoration(
                        hintText: "Search",
                        filled: true,
                        fillColor: Colors.white,
                        prefixIcon: IconButton(
                          icon: const Icon(
                            Icons.close,
                            size: 20,
                            color: Colors.grey,
                          ),
                          onPressed: _clearSearch,
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 0),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide(
                            color: Colors.grey.shade400,
                            width: 1,
                          ),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide(
                            color: Colors.grey.shade400,
                            width: 1,
                          ),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(24),
                          borderSide: BorderSide(
                            color: Colors.blueAccent,
                            width: 1.5,
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            // Scrollable Recent + Suggestions
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  // Recent section
                  if (_searchController.text.isEmpty) ...[
                    Text(
                      "Recent",
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 8),
                    SizedBox(
                      height: 100,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        itemCount: recentAccounts.length,
                        itemBuilder: (context, index) {
                          final acc = recentAccounts[index];
                          return Padding(
                            padding: const EdgeInsets.only(right: 16.0),
                            child: Column(
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border: Border.all(
                                      color: const Color.fromARGB(
                                        255,
                                        179,
                                        172,
                                        180,
                                      ),
                                      width: 1,
                                    ),
                                  ),
                                  child: CircleAvatar(
                                    radius: 28,
                                    backgroundColor: Colors.grey[300],
                                    child: Icon(
                                      Icons.person,
                                      size: 28,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 8),
                                Text(
                                  acc['username']!,
                                  style: GoogleFonts.poppins(fontSize: 12),
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 16),
                  ],

                  // Suggestions header
                  if (_searchController.text.isNotEmpty)
                    Text(
                      "Suggestions",
                      style: GoogleFonts.poppins(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  const SizedBox(height: 8),

                  // Suggestions list
                  ...filteredAccounts.map((acc) {
                    return Card(
                      margin: const EdgeInsets.only(bottom: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: ListTile(
                        leading: Container(
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(
                              color: const Color.fromARGB(255, 161, 103, 236),
                              width: 1,
                            ),
                          ),
                          child: CircleAvatar(
                            backgroundColor: Colors.grey[300],
                            child: const Icon(Icons.person, color: Colors.grey),
                          ),
                        ),
                        title: Text(
                          acc['username']!,
                          style: GoogleFonts.poppins(
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        subtitle: Text(
                          acc['name']!,
                          style: GoogleFonts.poppins(color: Colors.grey[700]),
                        ),
                        onTap: () {},
                      ),
                    );
                  }),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
